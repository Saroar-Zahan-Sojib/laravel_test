-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 16, 2022 at 04:18 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `techhunt_heichel_menachem`
--

-- --------------------------------------------------------

--
-- Table structure for table `albams_lists`
--

CREATE TABLE `albams_lists` (
  `id` int(11) NOT NULL,
  `nigunim_category_id` int(11) DEFAULT NULL,
  `nigunim_id` int(11) DEFAULT NULL,
  `albam_name` varchar(300) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `albams_lists`
--

INSERT INTO `albams_lists` (`id`, `nigunim_category_id`, `nigunim_id`, `albam_name`, `created_at`, `updated_at`) VALUES
(10, 9, 24, 'Demo Album', '2022-06-03 01:47:27', '2022-06-03 01:47:27'),
(11, 10, 24, 'Nigunei Chasidei Admur Haemtzoi', '2022-06-03 01:47:45', '2022-06-03 01:47:45'),
(13, 9, 24, NULL, '2022-06-08 22:37:00', '2022-06-08 22:43:11'),
(14, 10, 24, 'Test Album Test Album Test Album Test Album Test Album', '2022-06-14 21:41:00', '2022-06-14 21:41:00'),
(17, 11, 24, 'Demo album', '2022-09-08 23:11:13', '2022-09-08 23:11:13');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(18, 'Seforim', NULL, '2022-05-31 22:45:29', '2022-05-31 22:45:29'),
(19, 'Farbrengen', NULL, '2022-05-31 22:45:40', '2022-05-31 22:45:40'),
(20, 'Topics', NULL, '2022-05-31 22:45:44', '2022-05-31 22:45:44'),
(21, 'Maggidei Shiurim', NULL, '2022-06-02 19:42:02', '2022-06-02 19:42:02'),
(22, 'Kol Rabeinu', NULL, '2022-06-02 19:42:26', '2022-06-02 19:42:26'),
(23, 'Reb Yoel', NULL, '2022-06-02 19:42:36', '2022-06-02 19:42:36'),
(24, 'Nigunim', NULL, '2022-06-02 19:42:42', '2022-06-02 19:42:42'),
(25, 'Stories', NULL, '2022-06-02 19:42:47', '2022-06-02 19:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `category_types`
--

CREATE TABLE `category_types` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `type_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category_types`
--

INSERT INTO `category_types` (`id`, `category_id`, `type_name`, `created_at`, `updated_at`) VALUES
(11, 18, 'Sefrei Chasidus', '2022-05-31 22:46:05', '2022-05-31 22:46:05'),
(12, 18, 'Sefrei Nigle', '2022-05-31 22:46:18', '2022-05-31 22:46:18');

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `content_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `category_id`, `type_id`, `subcategory_id`, `content_name`, `created_at`, `updated_at`) VALUES
(22, 18, 11, 21, 'Tanya', '2022-05-31 17:47:51', '2022-05-31 17:47:51'),
(23, 18, 11, 21, 'Likutei Torah', '2022-05-31 17:47:51', '2022-05-31 17:47:51'),
(24, 18, 11, 21, 'Torah Or', '2022-05-31 17:47:51', '2022-05-31 17:47:51'),
(25, 18, 11, 21, '4 - Maamarei Admur Hazoken', '2022-06-02 20:04:04', '2022-06-02 20:04:04'),
(26, 18, 11, 21, '3 - Sidur Im Dach', '2022-06-02 20:04:04', '2022-06-02 20:04:04'),
(27, 18, 11, 21, 'Hadronim Al HaShas', '2022-06-02 20:04:04', '2022-06-02 20:04:04'),
(28, 18, 11, 21, 'Maamarei Admur Hazoken HaKtzorim', '2022-06-02 20:04:04', '2022-06-02 20:04:04'),
(29, 18, 11, 22, 'Toras Chaim', '2022-06-02 20:05:21', '2022-06-02 20:05:21'),
(30, 18, 11, 22, 'Shaarei Orah', '2022-06-02 20:05:21', '2022-06-02 20:05:21'),
(31, 18, 11, 23, 'Derech Mitzvosecha', '2022-06-02 20:07:41', '2022-06-02 20:07:41'),
(32, 18, 11, 24, 'Sefer Hamamorim Maharash 5626', '2022-06-02 20:08:28', '2022-06-02 20:08:28'),
(33, 18, 11, 24, 'Toras Shmuel', '2022-06-02 20:08:28', '2022-06-02 20:08:28'),
(34, 18, 11, 25, 'Sefer Hamamorim Rayatz 5685', '2022-06-02 20:09:57', '2022-06-02 20:09:57'),
(35, 18, 11, 25, 'Sefer Hamamorim Rayatz 5700', '2022-06-02 20:09:57', '2022-06-02 20:09:57'),
(36, 18, 11, 25, 'Sefer Hamamorim Rayatz 5686', '2022-06-02 20:09:57', '2022-06-02 20:09:57'),
(37, 18, 11, 24, 'Hayom yom', '2022-08-31 19:48:08', '2022-08-31 19:48:08');

-- --------------------------------------------------------

--
-- Table structure for table `current_parsha_lists`
--

CREATE TABLE `current_parsha_lists` (
  `id` int(11) NOT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `current_parsha_lists`
--

INSERT INTO `current_parsha_lists` (`id`, `main_cat_id`, `cat_id`, `type_id`, `content_id`, `created_at`, `updated_at`) VALUES
(1, 20, 5, 7, 11, '2022-06-16 21:48:09', '2022-06-16 21:48:09'),
(2, 20, 5, 7, 13, '2022-06-16 21:48:09', '2022-06-16 21:48:09'),
(3, 20, 5, 7, 15, '2022-06-16 21:48:09', '2022-06-16 21:48:09');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `created_at`, `updated_at`) VALUES
(3, '10 Sevat, Farbengin', '2022-08-13 14:39:10', '2022-08-13 14:39:10'),
(4, '11 Sevat, Farbengin', '2022-08-15 16:25:57', '2022-08-15 16:25:57'),
(5, '12 Sevat, Farbengin', '2022-08-15 16:26:07', '2022-08-15 16:26:07');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `inst_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `farbrengen_dates`
--

CREATE TABLE `farbrengen_dates` (
  `id` int(11) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farbrengen_dates`
--

INSERT INTO `farbrengen_dates` (`id`, `date`, `month`, `created_at`, `updated_at`) VALUES
(1, 'Vov Teshrei', NULL, '2022-08-19 04:40:42', '2022-08-19 04:40:42'),
(2, 'Vov Teshrei', 'Tishrei', '2022-08-19 06:43:31', '2022-08-19 06:43:31'),
(3, 'Yud Gimmel Teshrei', 'Tishrei', '2022-08-19 06:44:09', '2022-08-19 06:44:09');

-- --------------------------------------------------------

--
-- Table structure for table `farbrengen_files`
--

CREATE TABLE `farbrengen_files` (
  `id` int(11) NOT NULL,
  `month` int(11) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `file_or_link` int(11) DEFAULT NULL,
  `file_link_type` int(11) DEFAULT NULL,
  `file_type` int(11) DEFAULT NULL,
  `audio` text,
  `video` text,
  `audio_link` text,
  `video_link` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farbrengen_files`
--

INSERT INTO `farbrengen_files` (`id`, `month`, `date`, `speaker_id`, `title`, `description`, `file_or_link`, `file_link_type`, `file_type`, `audio`, `video`, `audio_link`, `video_link`, `created_at`, `updated_at`) VALUES
(7, 1, 1, 12, 'hhhhhhhh', NULL, 2, NULL, 2, NULL, '1661361332_1650698389_sample-mp4-file-small.mp4', NULL, NULL, '2022-08-24 22:15:32', '2022-08-24 22:15:32'),
(8, 1, 3, 13, 'hhhhhhhhhh', NULL, 2, NULL, 2, NULL, '1661361359_1650698389_sample-mp4-file-small.mp4', NULL, NULL, '2022-08-24 22:15:59', '2022-08-24 22:15:59'),
(9, 1, 3, 13, 'hhhhhhhhhh', NULL, 2, NULL, 2, NULL, '1661361385_1650698389_sample-mp4-file-small.mp4', NULL, NULL, '2022-08-24 22:16:25', '2022-08-24 22:16:25'),
(10, 1, 1, 12, 'Demo Ferbrengen', NULL, 2, NULL, 1, '1662660985_10-10.mp3', NULL, NULL, NULL, '2022-09-08 23:16:25', '2022-09-08 23:16:25');

-- --------------------------------------------------------

--
-- Table structure for table `farbrengen_months`
--

CREATE TABLE `farbrengen_months` (
  `id` int(11) NOT NULL,
  `month` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farbrengen_months`
--

INSERT INTO `farbrengen_months` (`id`, `month`, `created_at`, `updated_at`) VALUES
(1, 'Tishrei', '2022-08-19 04:29:28', '2022-08-19 04:29:28'),
(2, 'Cheshvan', '2022-09-08 23:15:23', '2022-09-08 23:15:23');

-- --------------------------------------------------------

--
-- Table structure for table `feature_files`
--

CREATE TABLE `feature_files` (
  `id` int(11) NOT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `short_description` text,
  `title` text,
  `topics` text,
  `file_type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `audio_link` text,
  `video_link` text,
  `file_link_type` int(11) DEFAULT NULL,
  `audio` text,
  `video` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feature_files`
--

INSERT INTO `feature_files` (`id`, `speaker_id`, `short_description`, `title`, `topics`, `file_type`, `status`, `audio_link`, `video_link`, `file_link_type`, `audio`, `video`, `created_at`, `updated_at`) VALUES
(1, NULL, 'gvvhvh', 'ghghgh', 'cfgfggf', 2, NULL, NULL, NULL, NULL, NULL, '1663313019_1650698389_sample-mp4-file-small.mp4', '2022-09-16 01:23:39', '2022-09-16 01:23:39'),
(2, 15, 'vvggvgvgv', 'hhhhhhhhhhhhh', 'hgvvggvvggv', 2, NULL, NULL, NULL, NULL, NULL, '1663319204_1650698389_sample-mp4-file-small.mp4', '2022-09-16 14:06:44', '2022-09-16 14:06:44');

-- --------------------------------------------------------

--
-- Table structure for table `following_speakers`
--

CREATE TABLE `following_speakers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `holiday_lists`
--

CREATE TABLE `holiday_lists` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `holiday_name` varchar(255) DEFAULT NULL,
  `date_from` varchar(255) DEFAULT NULL,
  `date_to` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `holiday_lists`
--

INSERT INTO `holiday_lists` (`id`, `category_id`, `main_cat_id`, `holiday_name`, `date_from`, `date_to`, `created_at`, `updated_at`) VALUES
(6, 6, 20, 'Rosh Hashana', '2022-07-05', '2022-08-01', '2022-06-16 21:43:58', '2022-06-16 21:50:08'),
(7, 6, 20, 'Yom Kippur', '2022-08-01', '2022-08-10', '2022-06-16 21:44:12', '2022-09-10 17:27:55'),
(8, 6, 20, 'Pesach', '2022-09-01', '2022-10-01', '2022-06-16 21:44:26', '2022-06-16 21:51:04'),
(9, 6, 20, 'Sefiras Haomer', NULL, NULL, '2022-06-16 21:44:42', '2022-06-16 21:44:42'),
(10, 6, 20, 'Elul', NULL, NULL, '2022-06-16 21:45:01', '2022-06-16 21:45:01'),
(11, 6, 20, 'Shavuos', NULL, NULL, '2022-06-16 21:45:13', '2022-06-16 21:45:13');

-- --------------------------------------------------------

--
-- Table structure for table `kol_rabeinu_categories`
--

CREATE TABLE `kol_rabeinu_categories` (
  `id` int(11) NOT NULL,
  `kol_id` int(11) DEFAULT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kol_rabeinu_categories`
--

INSERT INTO `kol_rabeinu_categories` (`id`, `kol_id`, `category_name`, `created_at`, `updated_at`) VALUES
(10, 22, 'Mammar', '2022-08-13 14:35:21', '2022-08-13 14:35:21'),
(11, 22, 'Niggun', '2022-08-13 14:35:36', '2022-08-13 14:35:36'),
(12, 22, 'Story', '2022-08-13 14:35:49', '2022-08-13 14:35:49'),
(13, 22, 'Sichos kodesh', '2022-08-13 14:35:58', '2022-08-13 14:35:58'),
(14, 22, 'Topics of Sichos', '2022-08-13 14:36:08', '2022-08-13 14:36:08');

-- --------------------------------------------------------

--
-- Table structure for table `kol_rabeinu_files`
--

CREATE TABLE `kol_rabeinu_files` (
  `id` int(11) NOT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `Category_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL,
  `event` int(11) DEFAULT NULL,
  `title` text,
  `description` text,
  `file_or_link` int(11) DEFAULT NULL,
  `file_link_type` int(11) DEFAULT NULL,
  `audio_link` text,
  `video_link` text,
  `file_type` int(11) DEFAULT NULL,
  `audio` text,
  `video` text,
  `feature_status` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kol_rabeinu_files`
--

INSERT INTO `kol_rabeinu_files` (`id`, `main_cat_id`, `Category_id`, `subcategory_id`, `year`, `month`, `event`, `title`, `description`, `file_or_link`, `file_link_type`, `audio_link`, `video_link`, `file_type`, `audio`, `video`, `feature_status`, `created_at`, `updated_at`) VALUES
(8, 22, 14, 11, NULL, NULL, NULL, 'Topics of sichos file', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660384203_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-13 14:50:03', '2022-08-13 14:50:03'),
(9, 22, 10, NULL, '5710', 'Tishrei', NULL, 'Mamar File', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660384251_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-13 14:50:51', '2022-08-13 14:50:51'),
(10, 22, 11, 9, NULL, NULL, NULL, 'Nigun File', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660384291_1650698389_sample-mp4-file-small.mp4', 1, '2022-08-13 14:51:31', '2022-08-13 14:54:49'),
(11, 22, 12, 10, NULL, NULL, NULL, 'Story', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660384423_1650698389_sample-mp4-file-small.mp4', 1, '2022-08-13 14:53:43', '2022-08-13 14:55:25'),
(12, 22, 14, 11, NULL, NULL, NULL, '13 Ikrim File', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660408651_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-13 21:37:31', '2022-08-13 21:37:31'),
(13, 22, 14, 11, NULL, NULL, NULL, 'File list', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660408688_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-13 21:38:08', '2022-08-13 21:38:08'),
(14, 22, 13, NULL, '5711', 'Tishrei', 3, 'rrrrrrrrr', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660562803_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:26:43', '2022-08-15 16:26:43'),
(15, 22, 13, NULL, '5711', 'Tevesh', 4, 'ffffffffffff', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660562843_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:27:23', '2022-08-15 16:27:23'),
(16, 22, 13, NULL, '5711', 'Shevat', 5, 'yyy', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660562916_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:28:36', '2022-08-15 16:28:36'),
(17, 22, 13, NULL, '5712', 'Tishrei', 3, 'rrrrrrrrrrrr', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660563097_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:31:37', '2022-08-15 16:31:37'),
(18, 22, 13, NULL, '5712', 'Tevesh', 4, 'ggggggggg', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660563136_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:32:16', '2022-08-15 16:32:16'),
(19, 22, 13, NULL, '5712', 'Shevat', 5, 'hhhhhhhhhhh', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660563185_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:33:05', '2022-08-15 16:33:05'),
(20, 22, 10, NULL, '5710', 'Tevesh', NULL, 'ggggggggg', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660564387_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:53:07', '2022-08-15 16:53:07'),
(21, 22, 10, NULL, '5711', 'Tishrei', NULL, 'eeeeeeeeeee', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660564423_1650698389_sample-mp4-file-small.mp4', 1, '2022-08-15 16:53:43', '2022-09-05 21:59:15'),
(22, 22, 10, NULL, '5711', 'Shevat', NULL, 'hhhhhhhhhh', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660564492_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:54:52', '2022-08-15 16:54:52'),
(23, 22, 10, NULL, '5712', 'Tishrei', NULL, 'fffffffffff', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660564526_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:55:26', '2022-08-15 16:55:26'),
(24, 22, 10, NULL, '5712', 'Shevat', NULL, 'ggggggggggg', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660564585_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-15 16:56:25', '2022-08-15 16:56:25');

-- --------------------------------------------------------

--
-- Table structure for table `kol_rabeinu_sub_categories`
--

CREATE TABLE `kol_rabeinu_sub_categories` (
  `id` int(11) NOT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `kol_rebeinu_sub_cat_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kol_rabeinu_sub_categories`
--

INSERT INTO `kol_rabeinu_sub_categories` (`id`, `main_cat_id`, `category_id`, `kol_rebeinu_sub_cat_name`, `created_at`, `updated_at`) VALUES
(9, 22, 11, 'nigun cat', '2022-08-13 14:43:44', '2022-08-13 14:43:44'),
(10, 22, 12, 'story cat 1', '2022-08-13 14:44:18', '2022-08-13 14:44:18'),
(11, 22, 14, '13 Ikrim: Moshiach', '2022-08-13 14:48:27', '2022-08-13 14:48:27'),
(12, 22, 14, '13 Ikrim: Schdus Hashem', '2022-08-13 21:30:33', '2022-08-13 21:30:33'),
(13, 22, 12, '15 Ikrim: Reward and punishment', '2022-08-13 21:34:19', '2022-08-13 21:34:19'),
(14, 22, 14, '16 Ikrim: Techiyas Hameisim', '2022-08-13 21:35:11', '2022-08-13 21:35:11'),
(15, 22, 14, '15 Ikrim: Reward and punishment', '2022-08-13 21:35:40', '2022-08-13 21:35:40'),
(16, 22, 14, '17 Ikrim: Moshiach', '2022-08-13 21:36:39', '2022-08-13 21:36:39');

-- --------------------------------------------------------

--
-- Table structure for table `lectures`
--

CREATE TABLE `lectures` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `subcontent_id` int(11) DEFAULT NULL,
  `lecture_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lectures`
--

INSERT INTO `lectures` (`id`, `category_id`, `type_id`, `subcategory_id`, `content_id`, `speaker_id`, `subcontent_id`, `lecture_name`, `created_at`, `updated_at`) VALUES
(21, 18, 11, 21, 22, 12, NULL, 'Likutei Amarim', '2022-05-31 17:49:44', '2022-05-31 17:49:44'),
(22, 18, 11, 21, 22, 12, NULL, 'Shaar Hayichud', '2022-05-31 17:49:44', '2022-05-31 17:49:44'),
(23, 18, 11, 21, 22, 12, NULL, 'Vhaemuna', '2022-05-31 17:49:44', '2022-05-31 17:49:44'),
(24, 18, 11, 21, 22, 12, NULL, 'Igeres Hatshuva', '2022-05-31 17:49:44', '2022-05-31 17:49:44'),
(25, 18, 11, 21, 23, NULL, NULL, 'Vayikra', '2022-06-02 20:30:52', '2022-06-02 20:30:52'),
(26, 18, 11, 21, 23, NULL, NULL, 'Bamidbar', '2022-06-02 20:30:52', '2022-06-02 20:30:52'),
(27, 18, 11, 21, 23, NULL, NULL, 'Devarim', '2022-06-02 20:30:52', '2022-06-02 20:30:52'),
(28, 18, 11, 21, 23, 12, NULL, 'Shaar Hayichud', '2022-06-05 17:02:37', '2022-06-05 17:02:37'),
(29, 18, 11, 21, 23, 12, NULL, 'Likutei Amarim', '2022-06-05 17:02:37', '2022-06-05 17:02:37'),
(30, 18, 11, 21, 23, 12, NULL, 'Vhaemuna', '2022-06-05 17:02:37', '2022-06-05 17:02:37'),
(31, 18, 11, 21, 24, 13, NULL, 'Likutei Amarim', '2022-06-05 17:03:43', '2022-06-05 17:03:43'),
(32, 18, 11, 21, 24, 13, NULL, 'Shaar Hayichud', '2022-06-05 17:03:43', '2022-06-05 17:03:43'),
(33, 18, 11, 21, 24, 13, NULL, 'Vhaemuna', '2022-06-05 17:03:43', '2022-06-05 17:03:43'),
(34, 18, 11, 21, 23, 12, NULL, 'Vayikra', '2022-09-08 17:25:01', '2022-09-08 17:25:01');

-- --------------------------------------------------------

--
-- Table structure for table `listen_later_files`
--

CREATE TABLE `listen_later_files` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `listen_later_files`
--

INSERT INTO `listen_later_files` (`id`, `user_id`, `file_id`, `created_at`, `updated_at`) VALUES
(42, 4, 12, '2022-06-10 12:13:03', '2022-06-10 12:13:03'),
(43, 4, 12, '2022-06-10 12:13:09', '2022-06-10 12:13:09'),
(44, 4, 12, '2022-06-10 12:13:12', '2022-06-10 12:13:12'),
(45, 4, 12, '2022-06-10 12:13:13', '2022-06-10 12:13:13'),
(46, 4, 12, '2022-06-10 12:13:13', '2022-06-10 12:13:13'),
(47, 4, 12, '2022-06-10 12:13:13', '2022-06-10 12:13:13'),
(48, 4, 12, '2022-06-10 12:13:13', '2022-06-10 12:13:13'),
(49, 4, 12, '2022-06-10 12:13:14', '2022-06-10 12:13:14'),
(50, 4, 12, '2022-06-10 12:13:14', '2022-06-10 12:13:14'),
(51, 4, 12, '2022-06-10 12:13:14', '2022-06-10 12:13:14'),
(52, 4, 12, '2022-06-10 12:13:14', '2022-06-10 12:13:14'),
(53, 4, 12, '2022-06-10 12:13:14', '2022-06-10 12:13:14'),
(54, 4, 12, '2022-06-10 12:13:14', '2022-06-10 12:13:14'),
(55, 4, 12, '2022-06-10 12:13:15', '2022-06-10 12:13:15'),
(56, 4, 12, '2022-06-10 12:13:15', '2022-06-10 12:13:15'),
(57, 4, 12, '2022-06-10 12:13:15', '2022-06-10 12:13:15'),
(58, 4, 12, '2022-06-10 12:13:15', '2022-06-10 12:13:15'),
(59, 4, 12, '2022-06-10 12:13:15', '2022-06-10 12:13:15'),
(60, 4, 12, '2022-06-10 12:13:16', '2022-06-10 12:13:16'),
(61, 4, 12, '2022-06-10 12:13:16', '2022-06-10 12:13:16'),
(62, 4, 12, '2022-06-10 12:13:16', '2022-06-10 12:13:16'),
(63, 4, 12, '2022-06-10 12:13:16', '2022-06-10 12:13:16'),
(64, 4, 12, '2022-06-10 12:13:16', '2022-06-10 12:13:16'),
(65, 4, 12, '2022-06-10 12:13:17', '2022-06-10 12:13:17'),
(66, 4, 12, '2022-06-10 12:13:17', '2022-06-10 12:13:17'),
(67, 4, 12, '2022-06-10 12:16:39', '2022-06-10 12:16:39'),
(68, 4, 12, '2022-06-10 12:16:39', '2022-06-10 12:16:39'),
(69, 4, 12, '2022-06-10 12:16:39', '2022-06-10 12:16:39'),
(70, 4, 12, '2022-06-10 12:16:39', '2022-06-10 12:16:39'),
(71, 4, 12, '2022-06-10 12:16:39', '2022-06-10 12:16:39'),
(72, 4, 12, '2022-06-10 12:16:39', '2022-06-10 12:16:39'),
(73, 4, 12, '2022-06-10 12:16:39', '2022-06-10 12:16:39'),
(74, 4, 12, '2022-06-10 12:16:40', '2022-06-10 12:16:40'),
(75, 4, 12, '2022-06-10 12:16:40', '2022-06-10 12:16:40'),
(76, 4, 12, '2022-06-10 12:16:40', '2022-06-10 12:16:40'),
(77, 4, 12, '2022-06-10 12:16:40', '2022-06-10 12:16:40'),
(78, 4, 12, '2022-06-10 12:16:40', '2022-06-10 12:16:40'),
(79, 4, 12, '2022-06-10 12:16:40', '2022-06-10 12:16:40'),
(80, 4, 12, '2022-06-10 12:16:40', '2022-06-10 12:16:40'),
(81, 4, 12, '2022-06-10 12:16:41', '2022-06-10 12:16:41'),
(82, 4, 12, '2022-06-10 12:16:45', '2022-06-10 12:16:45'),
(83, 4, 12, '2022-06-10 12:16:46', '2022-06-10 12:16:46'),
(84, 4, 12, '2022-06-10 12:16:46', '2022-06-10 12:16:46'),
(85, 4, 12, '2022-06-10 12:16:46', '2022-06-10 12:16:46'),
(86, 4, 12, '2022-06-10 12:16:46', '2022-06-10 12:16:46'),
(87, 4, 12, '2022-06-10 12:16:46', '2022-06-10 12:16:46'),
(88, 4, 12, '2022-06-10 12:16:46', '2022-06-10 12:16:46'),
(89, 4, 12, '2022-06-10 12:16:47', '2022-06-10 12:16:47'),
(90, 4, 12, '2022-06-10 12:16:47', '2022-06-10 12:16:47'),
(91, 4, 12, '2022-06-10 12:16:47', '2022-06-10 12:16:47'),
(92, 4, 12, '2022-06-10 12:16:47', '2022-06-10 12:16:47'),
(93, 4, 12, '2022-06-10 12:16:47', '2022-06-10 12:16:47'),
(94, 4, 12, '2022-06-10 12:16:48', '2022-06-10 12:16:48'),
(95, 4, 12, '2022-06-10 12:16:57', '2022-06-10 12:16:57'),
(96, 4, 12, '2022-06-10 12:16:57', '2022-06-10 12:16:57'),
(97, 4, 12, '2022-06-10 12:16:58', '2022-06-10 12:16:58'),
(98, 4, 12, '2022-06-10 12:16:58', '2022-06-10 12:16:58'),
(99, 4, 12, '2022-06-10 12:16:58', '2022-06-10 12:16:58'),
(100, 4, 12, '2022-06-10 12:16:58', '2022-06-10 12:16:58'),
(101, 4, 12, '2022-09-11 14:14:23', '2022-09-11 14:14:23'),
(102, 4, 12, '2022-09-11 14:14:23', '2022-09-11 14:14:23'),
(103, 4, 12, '2022-09-11 14:14:23', '2022-09-11 14:14:23'),
(104, 4, 12, '2022-09-11 14:14:23', '2022-09-11 14:14:23'),
(105, 4, 12, '2022-09-11 14:14:23', '2022-09-11 14:14:23'),
(106, 4, 12, '2022-09-11 14:14:23', '2022-09-11 14:14:23'),
(107, 4, 12, '2022-09-11 14:14:49', '2022-09-11 14:14:49'),
(108, 4, 12, '2022-09-11 14:14:49', '2022-09-11 14:14:49'),
(109, 4, 12, '2022-09-11 14:14:49', '2022-09-11 14:14:49'),
(110, 4, 12, '2022-09-11 14:14:49', '2022-09-11 14:14:49'),
(111, 4, 12, '2022-09-11 14:14:49', '2022-09-11 14:14:49'),
(112, 4, 12, '2022-09-11 14:14:49', '2022-09-11 14:14:49');

-- --------------------------------------------------------

--
-- Table structure for table `main_story_categories`
--

CREATE TABLE `main_story_categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `main_story_categories`
--

INSERT INTO `main_story_categories` (`id`, `category_name`, `created_at`, `updated_at`) VALUES
(1, 'Baal Shem Tov', '2022-08-19 02:15:51', '2022-08-19 02:15:51'),
(2, 'Baal Shem Tov', '2022-08-19 02:17:59', '2022-08-19 02:17:59'),
(4, 'Mezritcher Magid', '2022-09-08 23:12:14', '2022-09-08 23:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `months`
--

CREATE TABLE `months` (
  `id` int(11) NOT NULL,
  `month` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `months`
--

INSERT INTO `months` (`id`, `month`, `created_at`, `updated_at`) VALUES
(3, 'Tishrei', '2022-08-13 14:37:27', '2022-08-13 14:37:27'),
(4, 'Tevesh', '2022-08-15 16:25:01', '2022-08-15 16:25:01'),
(5, 'Shevat', '2022-08-15 16:25:09', '2022-08-15 16:25:09');

-- --------------------------------------------------------

--
-- Table structure for table `muggidei_lists`
--

CREATE TABLE `muggidei_lists` (
  `id` int(11) NOT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `title` text,
  `short_description` text,
  `topics` text,
  `file_or_link` int(11) DEFAULT NULL,
  `file_link_type` int(11) DEFAULT NULL,
  `link_type` int(11) DEFAULT NULL,
  `audio_link` text,
  `video_link` text,
  `file_type` int(11) DEFAULT NULL,
  `audio` text,
  `video` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `niggun_categories`
--

CREATE TABLE `niggun_categories` (
  `niggun_category_name` varchar(255) DEFAULT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `niggun_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `nigunim_categories`
--

CREATE TABLE `nigunim_categories` (
  `id` int(11) NOT NULL,
  `nigunim_id` int(11) DEFAULT NULL,
  `nigunim_name` varchar(255) DEFAULT NULL,
  `nigunim_category_name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nigunim_categories`
--

INSERT INTO `nigunim_categories` (`id`, `nigunim_id`, `nigunim_name`, `nigunim_category_name`, `created_at`, `updated_at`) VALUES
(9, 24, 'Nigunim', 'Heichel Negina', '2022-06-03 01:45:46', '2022-06-03 01:45:46'),
(10, 24, 'Nigunim', 'Nichoach', '2022-06-03 01:45:55', '2022-06-03 01:45:55'),
(11, 24, 'Nigunim', 'The Kapelle', '2022-06-03 01:46:10', '2022-06-03 01:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `nigunim_files`
--

CREATE TABLE `nigunim_files` (
  `id` int(11) NOT NULL,
  `nigunim_id` int(11) DEFAULT NULL,
  `nigunim_category_id` int(11) DEFAULT NULL,
  `nigunim_albam_id` int(11) DEFAULT NULL,
  `audio` text,
  `speaker_id` int(11) DEFAULT NULL,
  `title` text,
  `topics` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nigunim_files`
--

INSERT INTO `nigunim_files` (`id`, `nigunim_id`, `nigunim_category_id`, `nigunim_albam_id`, `audio`, `speaker_id`, `title`, `topics`, `created_at`, `updated_at`) VALUES
(12, 24, 9, 10, '1654202918_10-10.mp3', NULL, 'Audio 01', NULL, '2022-06-03 01:48:38', '2022-06-03 01:48:38'),
(13, 24, 10, 11, '1654202942_10-09.mp3', NULL, 'Audio 01', NULL, '2022-06-03 01:49:02', '2022-06-03 01:49:02'),
(14, 24, 11, 12, '1654202964_10-08.mp3', NULL, 'Audio 01', NULL, '2022-06-03 01:49:24', '2022-06-03 01:49:24'),
(15, 24, 11, 17, '1662660710_10-10.mp3', NULL, 'Music 01', NULL, '2022-09-08 23:11:50', '2022-09-08 23:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `parshioys_contents`
--

CREATE TABLE `parshioys_contents` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `content_name` varchar(300) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parshioys_contents`
--

INSERT INTO `parshioys_contents` (`id`, `category_id`, `main_cat_id`, `type_id`, `content_name`, `created_at`, `updated_at`) VALUES
(11, 5, 20, 7, 'Noach', '2022-06-16 21:39:46', '2022-06-16 21:39:46'),
(12, 5, 20, 7, 'Lech Lecha', '2022-06-16 21:40:06', '2022-06-16 21:40:06'),
(13, 5, 20, 7, 'Vayera', '2022-06-16 21:40:35', '2022-06-16 21:40:35'),
(14, 5, 20, 7, 'Chayei Sarah', '2022-06-16 21:40:57', '2022-06-16 21:40:57'),
(15, 5, 20, 7, 'Toldot', '2022-06-16 21:41:15', '2022-06-16 21:41:15'),
(16, 5, 20, 7, 'Vayetzei', '2022-06-16 21:41:29', '2022-06-16 21:41:29'),
(17, 5, 20, 7, 'Vayishlach', '2022-06-16 21:41:43', '2022-06-16 21:41:43'),
(18, 5, 20, 7, 'Vayeshev', '2022-06-16 21:41:57', '2022-06-16 21:41:57'),
(19, 5, 20, 7, 'Vayera', '2022-09-08 23:17:39', '2022-09-08 23:17:39');

-- --------------------------------------------------------

--
-- Table structure for table `parshiyos_files`
--

CREATE TABLE `parshiyos_files` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `holiday_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `inside_or_outside` int(11) DEFAULT NULL,
  `title` text,
  `description` text,
  `file_or_link` int(11) DEFAULT NULL,
  `file_link_type` int(11) DEFAULT NULL,
  `file_type` int(11) DEFAULT NULL,
  `audio` text,
  `video` text,
  `audio_link` text,
  `video_link` text,
  `date` char(255) DEFAULT NULL,
  `month` char(255) DEFAULT NULL,
  `feature_status` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parshiyos_files`
--

INSERT INTO `parshiyos_files` (`id`, `category_id`, `main_cat_id`, `holiday_id`, `type_id`, `content_id`, `group_id`, `speaker_id`, `inside_or_outside`, `title`, `description`, `file_or_link`, `file_link_type`, `file_type`, `audio`, `video`, `audio_link`, `video_link`, `date`, `month`, `feature_status`, `created_at`, `updated_at`) VALUES
(11, 5, 20, NULL, 7, 11, 1, 12, 1, NULL, NULL, 2, NULL, 2, NULL, '1655399614_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-16 22:13:34', '2022-06-16 22:13:34'),
(12, 5, 20, NULL, 7, 11, 1, 13, 1, 'tyrtyrturt', NULL, 2, NULL, 2, NULL, '1655399687_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, 1, '2022-06-16 22:14:47', '2022-09-16 14:07:18'),
(13, 6, 20, 6, NULL, NULL, 1, 14, 1, 'TTTTTTTT', NULL, 2, NULL, 2, NULL, '1655399763_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-16 22:16:03', '2022-06-16 22:16:03'),
(14, 7, 20, NULL, NULL, NULL, 1, 12, 1, 'Ikrim File', NULL, 2, NULL, 2, NULL, '1655654224_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-19 20:57:04', '2022-06-19 20:57:04'),
(15, 7, 20, NULL, NULL, NULL, 1, 13, 1, 'Group title File', NULL, 2, NULL, 2, NULL, '1655659467_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-19 22:24:27', '2022-06-19 22:24:27'),
(16, 7, 20, NULL, NULL, NULL, 2, 14, 1, 'Group 2 File', NULL, 2, NULL, 2, NULL, '1655659507_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-19 22:25:07', '2022-06-19 22:25:07'),
(17, 7, 20, NULL, NULL, NULL, 4, 12, 1, 'No Group File', NULL, 2, NULL, 2, NULL, '1655659570_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-19 22:26:10', '2022-06-19 22:26:10'),
(18, 5, 20, NULL, 7, 11, 1, 13, 1, 'Group File', NULL, 2, NULL, 2, NULL, '1655660893_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, 1, '2022-06-19 22:48:13', '2022-09-16 14:07:25'),
(19, 5, 20, NULL, 7, 11, 1, 13, 1, 'Group File', NULL, 2, NULL, 2, NULL, '1655660925_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, 1, '2022-06-19 22:48:45', '2022-09-16 14:07:32'),
(20, 5, 20, NULL, 7, 11, 2, 15, 1, 'Group 2 file', NULL, 2, NULL, 2, NULL, '1655660959_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-19 22:49:19', '2022-06-19 22:49:19'),
(21, 5, 20, NULL, 7, 11, 4, 17, 1, 'jhjhgbkjbk', NULL, 2, NULL, 2, NULL, '1655661053_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-19 22:50:53', '2022-06-19 22:50:53'),
(22, 6, 20, 6, NULL, NULL, 1, 14, 1, 'Group File', NULL, 2, NULL, 2, NULL, '1655661464_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-06-19 22:57:44', '2022-06-19 22:57:44'),
(23, 12, 20, NULL, NULL, NULL, 1, 15, 1, 'Inyonei geulah file', NULL, 2, NULL, 2, NULL, '1662395719_1650698389_sample-mp4-file-small.mp4', NULL, NULL, '13', '09', NULL, '2022-09-05 21:35:19', '2022-09-13 23:09:49'),
(24, 5, 20, NULL, 7, 13, 2, 12, 1, 'Demo class 01', NULL, 2, NULL, 1, '1662661142_11-01.mp3', NULL, NULL, NULL, NULL, NULL, NULL, '2022-09-08 23:19:02', '2022-09-08 23:19:02'),
(25, 6, 20, 8, NULL, NULL, 1, 15, 1, 'holiday file', NULL, 2, NULL, 2, NULL, '1662812967_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, NULL, NULL, '2022-09-10 17:29:27', '2022-09-10 17:29:27');

-- --------------------------------------------------------

--
-- Table structure for table `parshiyos_groups`
--

CREATE TABLE `parshiyos_groups` (
  `id` int(11) NOT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `group_name` varchar(300) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parshiyos_groups`
--

INSERT INTO `parshiyos_groups` (`id`, `main_cat_id`, `group_name`, `created_at`, `updated_at`) VALUES
(1, 6, 'Group Title', '2022-06-03 02:59:34', '2022-06-03 02:59:34'),
(2, 20, 'Group 2', '2022-06-19 22:23:08', '2022-06-19 22:23:08'),
(3, 20, 'Group 3', '2022-06-19 22:23:15', '2022-06-19 22:23:15'),
(4, 20, 'NoGroup', '2022-06-19 22:23:24', '2022-06-19 22:23:24');

-- --------------------------------------------------------

--
-- Table structure for table `parshiyos_types`
--

CREATE TABLE `parshiyos_types` (
  `id` int(11) NOT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `parshiyos_name` varchar(255) DEFAULT NULL,
  `type_name` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parshiyos_types`
--

INSERT INTO `parshiyos_types` (`id`, `main_cat_id`, `category_id`, `parshiyos_name`, `type_name`, `created_at`, `updated_at`) VALUES
(7, 20, 5, 'Parshiyos', 'Bereshit', '2022-06-16 21:37:28', '2022-06-16 21:37:28'),
(8, 20, 5, 'Parshiyos', 'Shemot', '2022-06-16 21:37:49', '2022-06-16 21:37:49'),
(9, 20, 5, 'Parshiyos', 'Vayikra', '2022-06-16 21:38:04', '2022-06-16 21:38:04'),
(10, 20, 5, 'Parshiyos', 'Bamidbar', '2022-06-16 21:38:17', '2022-06-16 21:38:17'),
(11, 20, 5, 'Parshiyos', 'Devarim', '2022-06-16 21:38:30', '2022-06-16 21:38:30');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `inst_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `exam_type` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `content` int(11) NOT NULL,
  `mark` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `options` int(11) NOT NULL,
  `answers` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recently_played_lists`
--

CREATE TABLE `recently_played_lists` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recently_played_lists`
--

INSERT INTO `recently_played_lists` (`id`, `user_id`, `file_id`, `created_at`, `updated_at`) VALUES
(106, 4, 51, '2022-06-07 23:34:07', '2022-06-07 23:34:07'),
(107, 4, 68, '2022-06-07 23:34:49', '2022-06-07 23:34:49'),
(108, 4, 51, '2022-06-08 22:50:25', '2022-06-08 22:50:25'),
(109, 4, 51, '2022-06-08 23:00:59', '2022-06-08 23:00:59'),
(110, 4, 51, '2022-06-08 23:03:11', '2022-06-08 23:03:11'),
(111, 4, 51, '2022-06-08 23:03:38', '2022-06-08 23:03:38'),
(112, 4, 51, '2022-06-08 23:26:35', '2022-06-08 23:26:35'),
(113, 4, 51, '2022-06-08 23:41:25', '2022-06-08 23:41:25'),
(114, 4, 51, '2022-06-08 23:45:50', '2022-06-08 23:45:50'),
(115, 4, 51, '2022-06-09 00:24:31', '2022-06-09 00:24:31'),
(116, 4, 51, '2022-06-09 00:28:08', '2022-06-09 00:28:08'),
(117, 4, 51, '2022-06-09 00:45:50', '2022-06-09 00:45:50'),
(118, 4, 51, '2022-06-09 00:51:40', '2022-06-09 00:51:40'),
(119, 4, 51, '2022-06-09 00:58:09', '2022-06-09 00:58:09'),
(120, 4, 51, '2022-06-09 02:03:01', '2022-06-09 02:03:01'),
(121, 4, 51, '2022-06-09 07:58:26', '2022-06-09 07:58:26'),
(122, 4, 51, '2022-06-09 22:41:09', '2022-06-09 22:41:09'),
(123, 4, 51, '2022-06-09 22:42:07', '2022-06-09 22:42:07'),
(124, 4, 51, '2022-06-09 22:43:33', '2022-06-09 22:43:33'),
(125, 4, 51, '2022-06-09 22:53:26', '2022-06-09 22:53:26'),
(126, 4, 51, '2022-06-09 22:58:00', '2022-06-09 22:58:00'),
(127, 4, 51, '2022-06-09 23:00:09', '2022-06-09 23:00:09'),
(128, 4, 51, '2022-06-09 23:00:44', '2022-06-09 23:00:44'),
(129, 4, 51, '2022-06-09 23:01:03', '2022-06-09 23:01:03'),
(130, 4, 51, '2022-06-09 23:30:54', '2022-06-09 23:30:54'),
(131, 4, 51, '2022-06-09 23:32:24', '2022-06-09 23:32:24'),
(132, 4, 51, '2022-06-09 23:33:35', '2022-06-09 23:33:35'),
(133, 4, 51, '2022-06-09 23:33:57', '2022-06-09 23:33:57'),
(134, 4, 51, '2022-06-09 23:45:46', '2022-06-09 23:45:46'),
(135, 4, 51, '2022-06-09 23:49:36', '2022-06-09 23:49:36'),
(136, 4, 51, '2022-06-09 23:54:55', '2022-06-09 23:54:55'),
(137, 4, 51, '2022-06-10 00:06:41', '2022-06-10 00:06:41'),
(138, 4, 51, '2022-06-10 00:26:03', '2022-06-10 00:26:03'),
(139, 4, 69, '2022-06-10 12:26:31', '2022-06-10 12:26:31'),
(140, 4, 51, '2022-06-10 12:52:21', '2022-06-10 12:52:21'),
(141, 4, 51, '2022-06-10 15:22:34', '2022-06-10 15:22:34'),
(142, 4, 51, '2022-06-10 22:02:34', '2022-06-10 22:02:34'),
(143, 4, 51, '2022-06-10 22:06:46', '2022-06-10 22:06:46'),
(144, 4, 51, '2022-06-10 22:33:14', '2022-06-10 22:33:14'),
(145, 4, 51, '2022-06-10 22:34:05', '2022-06-10 22:34:05'),
(146, 4, 51, '2022-06-10 22:37:27', '2022-06-10 22:37:27'),
(147, 4, 51, '2022-06-10 22:41:40', '2022-06-10 22:41:40'),
(148, 4, 51, '2022-06-10 22:45:38', '2022-06-10 22:45:38'),
(149, 4, 51, '2022-06-10 22:45:43', '2022-06-10 22:45:43'),
(150, 4, 51, '2022-06-10 22:45:54', '2022-06-10 22:45:54'),
(151, 4, 51, '2022-06-10 22:46:11', '2022-06-10 22:46:11'),
(152, 4, 51, '2022-06-10 22:46:16', '2022-06-10 22:46:16'),
(153, 4, 51, '2022-06-10 22:46:23', '2022-06-10 22:46:23'),
(154, 4, 51, '2022-06-10 22:46:29', '2022-06-10 22:46:29'),
(155, 4, 51, '2022-06-10 22:47:47', '2022-06-10 22:47:47'),
(156, 4, 51, '2022-06-10 22:47:54', '2022-06-10 22:47:54'),
(157, 4, 51, '2022-06-10 22:48:02', '2022-06-10 22:48:02'),
(158, 4, 51, '2022-06-10 22:48:29', '2022-06-10 22:48:29'),
(159, 4, 51, '2022-06-10 22:48:59', '2022-06-10 22:48:59'),
(160, 4, 51, '2022-06-10 22:50:08', '2022-06-10 22:50:08'),
(161, 4, 51, '2022-06-10 22:50:14', '2022-06-10 22:50:14'),
(162, 4, 51, '2022-06-10 22:50:25', '2022-06-10 22:50:25'),
(163, 4, 51, '2022-06-10 22:50:26', '2022-06-10 22:50:26'),
(164, 4, 51, '2022-06-10 22:50:30', '2022-06-10 22:50:30'),
(165, 4, 51, '2022-06-10 22:52:00', '2022-06-10 22:52:00'),
(166, 4, 51, '2022-06-10 22:52:04', '2022-06-10 22:52:04'),
(167, 4, 51, '2022-06-10 22:52:08', '2022-06-10 22:52:08'),
(168, 4, 51, '2022-06-10 22:52:10', '2022-06-10 22:52:10'),
(169, 4, 51, '2022-06-10 22:54:25', '2022-06-10 22:54:25'),
(170, 4, 51, '2022-06-10 22:54:29', '2022-06-10 22:54:29'),
(171, 4, 51, '2022-06-10 22:54:31', '2022-06-10 22:54:31'),
(172, 4, 51, '2022-06-10 22:54:33', '2022-06-10 22:54:33'),
(173, 4, 51, '2022-06-10 22:54:38', '2022-06-10 22:54:38'),
(174, 4, 51, '2022-06-10 22:54:39', '2022-06-10 22:54:39'),
(175, 4, 51, '2022-06-10 22:54:41', '2022-06-10 22:54:41'),
(176, 4, 51, '2022-06-10 22:54:43', '2022-06-10 22:54:43'),
(177, 4, 51, '2022-06-10 22:54:44', '2022-06-10 22:54:44'),
(178, 4, 51, '2022-06-10 22:54:47', '2022-06-10 22:54:47'),
(179, 4, 51, '2022-06-10 22:54:50', '2022-06-10 22:54:50'),
(180, 4, 51, '2022-06-10 22:54:54', '2022-06-10 22:54:54'),
(181, 4, 51, '2022-06-10 22:54:56', '2022-06-10 22:54:56'),
(182, 4, 51, '2022-06-10 23:11:26', '2022-06-10 23:11:26'),
(183, 4, 51, '2022-06-10 23:12:24', '2022-06-10 23:12:24'),
(184, 4, 51, '2022-06-10 23:14:36', '2022-06-10 23:14:36'),
(185, 4, 51, '2022-06-10 23:15:07', '2022-06-10 23:15:07'),
(186, 4, 51, '2022-06-10 23:28:36', '2022-06-10 23:28:36'),
(187, 4, 68, '2022-06-10 23:30:48', '2022-06-10 23:30:48'),
(188, 4, 51, '2022-06-10 23:37:48', '2022-06-10 23:37:48'),
(189, 4, 51, '2022-06-10 23:37:57', '2022-06-10 23:37:57'),
(190, 4, 51, '2022-06-10 23:39:10', '2022-06-10 23:39:10'),
(191, 4, 51, '2022-06-10 23:39:12', '2022-06-10 23:39:12'),
(192, 4, 51, '2022-06-10 23:39:14', '2022-06-10 23:39:14'),
(193, 4, 51, '2022-06-10 23:39:16', '2022-06-10 23:39:16'),
(194, 4, 51, '2022-06-10 23:39:17', '2022-06-10 23:39:17'),
(195, 4, 51, '2022-06-10 23:39:20', '2022-06-10 23:39:20'),
(196, 4, 51, '2022-06-10 23:39:23', '2022-06-10 23:39:23'),
(197, 4, 51, '2022-06-10 23:39:38', '2022-06-10 23:39:38'),
(198, 4, 51, '2022-06-10 23:39:42', '2022-06-10 23:39:42'),
(199, 4, 51, '2022-06-10 23:39:44', '2022-06-10 23:39:44'),
(200, 4, 51, '2022-06-10 23:39:45', '2022-06-10 23:39:45'),
(201, 4, 51, '2022-06-10 23:45:42', '2022-06-10 23:45:42'),
(202, 4, 51, '2022-06-10 23:51:25', '2022-06-10 23:51:25'),
(203, 4, 51, '2022-06-10 23:52:04', '2022-06-10 23:52:04'),
(204, 4, 51, '2022-06-10 23:52:49', '2022-06-10 23:52:49'),
(205, 4, 51, '2022-06-13 21:27:23', '2022-06-13 21:27:23'),
(206, 4, 68, '2022-06-13 23:25:17', '2022-06-13 23:25:17'),
(207, 4, 51, '2022-06-14 07:15:11', '2022-06-14 07:15:11'),
(208, 4, 51, '2022-06-14 07:17:43', '2022-06-14 07:17:43'),
(209, 4, 51, '2022-06-14 07:18:26', '2022-06-14 07:18:26'),
(210, 4, 51, '2022-06-14 20:37:35', '2022-06-14 20:37:35'),
(211, 4, 51, '2022-06-14 20:39:08', '2022-06-14 20:39:08'),
(212, 4, 51, '2022-06-14 20:39:39', '2022-06-14 20:39:39'),
(213, 4, 69, '2022-06-14 21:02:21', '2022-06-14 21:02:21'),
(214, 4, 51, '2022-06-14 22:58:26', '2022-06-14 22:58:26'),
(215, 4, 51, '2022-06-14 23:10:28', '2022-06-14 23:10:28'),
(216, 4, 51, '2022-06-14 23:15:53', '2022-06-14 23:15:53'),
(217, 4, 51, '2022-06-14 23:29:20', '2022-06-14 23:29:20'),
(218, 4, 51, '2022-06-14 23:41:08', '2022-06-14 23:41:08'),
(219, 4, 51, '2022-06-14 23:56:33', '2022-06-14 23:56:33'),
(220, 4, 51, '2022-06-14 23:57:00', '2022-06-14 23:57:00'),
(221, 4, 51, '2022-06-14 23:57:10', '2022-06-14 23:57:10'),
(222, 4, 51, '2022-06-15 00:32:11', '2022-06-15 00:32:11'),
(223, 4, 51, '2022-06-15 00:34:45', '2022-06-15 00:34:45'),
(224, 4, 51, '2022-06-15 00:47:35', '2022-06-15 00:47:35'),
(225, 4, 51, '2022-06-16 22:55:16', '2022-06-16 22:55:16'),
(226, 4, 51, '2022-06-16 23:02:21', '2022-06-16 23:02:21'),
(227, 4, 51, '2022-06-16 23:05:49', '2022-06-16 23:05:49'),
(228, 4, 51, '2022-06-17 00:16:05', '2022-06-17 00:16:05'),
(229, 4, 51, '2022-06-17 00:16:51', '2022-06-17 00:16:51'),
(230, 4, 51, '2022-06-17 00:18:10', '2022-06-17 00:18:10'),
(231, 4, 69, '2022-06-17 18:14:36', '2022-06-17 18:14:36'),
(232, 4, 70, '2022-06-21 22:44:22', '2022-06-21 22:44:22'),
(233, 4, 71, '2022-06-21 22:46:06', '2022-06-21 22:46:06'),
(234, 4, 51, '2022-06-24 17:23:51', '2022-06-24 17:23:51'),
(235, 4, 51, '2022-06-25 22:07:10', '2022-06-25 22:07:10'),
(236, 4, 70, '2022-06-28 22:56:23', '2022-06-28 22:56:23'),
(237, 4, 51, '2022-07-21 01:07:02', '2022-07-21 01:07:02'),
(238, 4, 68, '2022-07-24 07:15:48', '2022-07-24 07:15:48'),
(239, 4, 51, '2022-07-26 21:57:25', '2022-07-26 21:57:25'),
(240, 4, 51, '2022-07-26 21:58:49', '2022-07-26 21:58:49'),
(241, 4, 51, '2022-07-26 22:16:54', '2022-07-26 22:16:54'),
(242, 4, 51, '2022-07-26 22:33:19', '2022-07-26 22:33:19'),
(243, 4, 51, '2022-07-26 22:33:36', '2022-07-26 22:33:36'),
(244, 4, 51, '2022-07-26 22:36:35', '2022-07-26 22:36:35'),
(245, 4, 51, '2022-07-26 22:37:24', '2022-07-26 22:37:24'),
(246, 4, 51, '2022-07-26 22:38:45', '2022-07-26 22:38:45'),
(247, 4, 51, '2022-07-28 23:42:55', '2022-07-28 23:42:55'),
(248, 4, 51, '2022-07-29 23:27:50', '2022-07-29 23:27:50'),
(249, 4, 51, '2022-07-29 23:40:21', '2022-07-29 23:40:21'),
(250, 4, 51, '2022-07-29 23:56:40', '2022-07-29 23:56:40'),
(251, 4, 51, '2022-07-29 23:59:01', '2022-07-29 23:59:01'),
(252, 4, 51, '2022-07-30 00:02:14', '2022-07-30 00:02:14'),
(253, 4, 51, '2022-07-30 00:08:05', '2022-07-30 00:08:05'),
(254, 4, 51, '2022-07-30 00:09:55', '2022-07-30 00:09:55'),
(255, 4, 51, '2022-07-30 00:17:11', '2022-07-30 00:17:11'),
(256, 4, 51, '2022-07-30 00:40:10', '2022-07-30 00:40:10'),
(257, 4, 51, '2022-07-30 00:41:17', '2022-07-30 00:41:17'),
(258, 4, 51, '2022-07-30 00:42:16', '2022-07-30 00:42:16'),
(259, 4, 51, '2022-07-30 00:45:22', '2022-07-30 00:45:22'),
(260, 4, 51, '2022-07-30 01:10:55', '2022-07-30 01:10:55'),
(261, 4, 51, '2022-08-01 22:29:21', '2022-08-01 22:29:21'),
(262, 4, 51, '2022-08-01 22:33:18', '2022-08-01 22:33:18'),
(263, 4, 51, '2022-08-01 22:42:53', '2022-08-01 22:42:53'),
(264, 4, 51, '2022-08-01 23:05:47', '2022-08-01 23:05:47'),
(265, 4, 51, '2022-08-01 23:08:02', '2022-08-01 23:08:02'),
(266, 4, 51, '2022-08-01 23:13:38', '2022-08-01 23:13:38'),
(267, 4, 51, '2022-08-01 23:19:55', '2022-08-01 23:19:55'),
(268, 4, 51, '2022-08-01 23:28:45', '2022-08-01 23:28:45'),
(269, 4, 51, '2022-08-02 00:39:14', '2022-08-02 00:39:14'),
(270, 4, 51, '2022-08-02 00:40:14', '2022-08-02 00:40:14'),
(271, 4, 51, '2022-08-02 00:44:31', '2022-08-02 00:44:31'),
(272, 4, 51, '2022-08-07 00:41:14', '2022-08-07 00:41:14'),
(273, 4, 51, '2022-08-07 00:44:01', '2022-08-07 00:44:01'),
(274, 4, 51, '2022-08-07 00:48:42', '2022-08-07 00:48:42'),
(275, 4, 51, '2022-08-07 00:49:21', '2022-08-07 00:49:21'),
(276, 4, 51, '2022-08-07 00:52:35', '2022-08-07 00:52:35'),
(277, 4, 51, '2022-08-07 00:55:24', '2022-08-07 00:55:24'),
(278, 4, 51, '2022-08-07 01:02:23', '2022-08-07 01:02:23'),
(279, 4, 51, '2022-08-07 01:13:02', '2022-08-07 01:13:02'),
(280, 4, 68, '2022-08-07 06:35:00', '2022-08-07 06:35:00'),
(281, 4, 68, '2022-08-07 06:35:52', '2022-08-07 06:35:52'),
(282, 4, 10, '2022-08-18 14:41:20', '2022-08-18 14:41:20'),
(283, 4, 11, '2022-08-18 14:42:40', '2022-08-18 14:42:40'),
(284, 4, 1, '2022-08-20 01:22:17', '2022-08-20 01:22:17'),
(285, 4, 2, '2022-08-20 01:22:25', '2022-08-20 01:22:25'),
(286, 4, 1, '2022-08-20 22:28:57', '2022-08-20 22:28:57'),
(287, 4, 1, '2022-08-20 22:29:19', '2022-08-20 22:29:19'),
(288, 4, 1, '2022-08-20 22:29:22', '2022-08-20 22:29:22'),
(289, 4, 1, '2022-08-20 22:29:57', '2022-08-20 22:29:57'),
(290, 4, 1, '2022-08-20 22:30:06', '2022-08-20 22:30:06'),
(291, 4, 68, '2022-08-21 20:52:31', '2022-08-21 20:52:31'),
(292, 4, 51, '2022-08-24 00:28:53', '2022-08-24 00:28:53'),
(293, 4, 51, '2022-08-24 22:24:53', '2022-08-24 22:24:53'),
(294, 4, 70, '2022-08-24 23:05:11', '2022-08-24 23:05:11'),
(295, 4, 68, '2022-08-25 05:59:44', '2022-08-25 05:59:44'),
(296, 4, 68, '2022-08-25 06:00:36', '2022-08-25 06:00:36'),
(297, 4, 10, '2022-08-28 01:26:22', '2022-08-28 01:26:22'),
(298, 4, 1, '2022-08-28 01:26:44', '2022-08-28 01:26:44'),
(299, 4, 1, '2022-08-28 01:26:56', '2022-08-28 01:26:56'),
(300, 4, 2, '2022-08-28 01:27:09', '2022-08-28 01:27:09'),
(301, 4, 51, '2022-08-28 01:28:44', '2022-08-28 01:28:44'),
(302, 4, 68, '2022-08-28 06:05:39', '2022-08-28 06:05:39'),
(303, 4, 68, '2022-08-28 18:19:44', '2022-08-28 18:19:44'),
(304, 4, 51, '2022-08-29 18:08:51', '2022-08-29 18:08:51'),
(305, 4, 51, '2022-08-29 18:19:11', '2022-08-29 18:19:11'),
(306, 4, 51, '2022-08-30 06:40:21', '2022-08-30 06:40:21'),
(307, 4, 68, '2022-08-30 06:41:17', '2022-08-30 06:41:17'),
(308, 4, 68, '2022-08-31 06:58:25', '2022-08-31 06:58:25'),
(309, 4, 10, '2022-08-31 06:59:26', '2022-08-31 06:59:26'),
(310, 4, 51, '2022-08-31 20:59:59', '2022-08-31 20:59:59'),
(311, 4, 1, '2022-08-31 21:05:00', '2022-08-31 21:05:00'),
(312, 4, 68, '2022-09-05 04:15:46', '2022-09-05 04:15:46'),
(313, 4, 68, '2022-09-05 05:39:18', '2022-09-05 05:39:18'),
(314, 4, 68, '2022-09-05 05:39:50', '2022-09-05 05:39:50'),
(315, 4, 68, '2022-09-07 02:09:05', '2022-09-07 02:09:05'),
(316, 4, 51, '2022-09-07 07:05:30', '2022-09-07 07:05:30'),
(317, 4, 51, '2022-09-07 07:06:17', '2022-09-07 07:06:17'),
(318, 4, 51, '2022-09-07 23:50:51', '2022-09-07 23:50:51'),
(319, 4, 51, '2022-09-07 23:51:21', '2022-09-07 23:51:21'),
(320, 4, 1, '2022-09-07 23:54:00', '2022-09-07 23:54:00'),
(321, 4, 68, '2022-09-08 00:02:29', '2022-09-08 00:02:29'),
(322, 4, 68, '2022-09-08 00:02:46', '2022-09-08 00:02:46'),
(323, 4, 68, '2022-09-08 00:15:33', '2022-09-08 00:15:33'),
(324, 4, 21, '2022-09-08 00:16:29', '2022-09-08 00:16:29'),
(325, 4, 1, '2022-09-08 00:22:32', '2022-09-08 00:22:32'),
(326, 4, 51, '2022-09-08 22:22:07', '2022-09-08 22:22:07'),
(327, 4, 51, '2022-09-08 22:22:21', '2022-09-08 22:22:21'),
(328, 4, 51, '2022-09-08 22:22:31', '2022-09-08 22:22:31'),
(329, 4, 51, '2022-09-11 14:16:08', '2022-09-11 14:16:08'),
(330, 4, 70, '2022-09-13 00:48:40', '2022-09-13 00:48:40'),
(331, 4, 70, '2022-09-13 00:48:44', '2022-09-13 00:48:44'),
(332, 4, 71, '2022-09-13 00:48:48', '2022-09-13 00:48:48'),
(333, 4, 71, '2022-09-13 00:48:53', '2022-09-13 00:48:53'),
(334, 4, 72, '2022-09-13 00:48:57', '2022-09-13 00:48:57'),
(335, 4, 72, '2022-09-13 00:49:01', '2022-09-13 00:49:01'),
(336, 4, 21, '2022-09-13 00:50:25', '2022-09-13 00:50:25'),
(337, 4, 10, '2022-09-13 00:50:29', '2022-09-13 00:50:29'),
(338, 4, 11, '2022-09-13 00:50:31', '2022-09-13 00:50:31'),
(339, 4, 23, '2022-09-13 22:37:27', '2022-09-13 22:37:27'),
(340, 4, 10, '2022-09-13 22:59:28', '2022-09-13 22:59:28'),
(341, 4, 51, '2022-09-13 23:44:41', '2022-09-13 23:44:41'),
(342, 4, 21, '2022-09-13 23:44:52', '2022-09-13 23:44:52'),
(343, 4, 21, '2022-09-14 00:36:44', '2022-09-14 00:36:44'),
(344, 4, 1, '2022-09-14 00:38:45', '2022-09-14 00:38:45');

-- --------------------------------------------------------

--
-- Table structure for table `speakers`
--

CREATE TABLE `speakers` (
  `id` int(11) NOT NULL,
  `speaker_name` text COLLATE utf8_unicode_ci,
  `short_description` text COLLATE utf8_unicode_ci,
  `speaker_image` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `speakers`
--

INSERT INTO `speakers` (`id`, `speaker_name`, `short_description`, `speaker_image`, `created_at`, `updated_at`) VALUES
(12, 'Leibel Altein', NULL, '1650831833_6.jpg', '2022-04-24 20:23:53', '2022-04-24 20:23:53'),
(13, 'Chaim Shaul Bruk', NULL, '1650831879_6.jpg', '2022-04-24 20:24:39', '2022-04-24 20:24:39'),
(14, 'Yoel kahn', NULL, '1650987486_Untitled.png', '2022-04-26 15:38:06', '2022-04-26 15:38:06'),
(15, 'Reb Yisroel Friedman', NULL, '1652206723_Untitled.png', '2022-05-10 18:18:43', '2022-05-10 18:18:43'),
(16, 'Reb Shmuel Heber', NULL, '1652206741_Untitled.png', '2022-05-10 18:19:01', '2022-05-10 18:19:01'),
(17, 'Reb Leibel Schapiro', NULL, '1652206756_Untitled.png', '2022-05-10 18:19:16', '2022-05-10 18:19:16'),
(18, 'Reb Leima Wilhelm', NULL, '1652206810_Untitled.png', '2022-05-10 18:20:10', '2022-05-10 18:20:10'),
(19, 'Reb Ephraim Piekarski', NULL, '1652206820_Untitled.png', '2022-05-10 18:20:20', '2022-05-10 18:20:20'),
(20, 'Reb Shlomo Majeski', NULL, '1652206840_Untitled.png', '2022-05-10 18:20:40', '2022-05-10 18:20:40'),
(21, 'Reb Berel Lipsker', NULL, '1652206861_Untitled.png', '2022-05-10 18:21:01', '2022-05-10 18:21:01');

-- --------------------------------------------------------

--
-- Table structure for table `std_classes`
--

CREATE TABLE `std_classes` (
  `id` int(11) NOT NULL,
  `inst_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `story_categories`
--

CREATE TABLE `story_categories` (
  `id` int(11) NOT NULL,
  `story_category_name` varchar(255) DEFAULT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `story_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `story_categories`
--

INSERT INTO `story_categories` (`id`, `story_category_name`, `main_cat_id`, `story_id`, `created_at`, `updated_at`) VALUES
(1, 'Baal Shem Tom', 7, 3, '2022-06-17 12:52:13', '2022-06-17 12:52:13'),
(2, 'Mezritcher Magid', 7, 3, '2022-06-17 12:52:54', '2022-06-17 12:52:54');

-- --------------------------------------------------------

--
-- Table structure for table `story_files`
--

CREATE TABLE `story_files` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `file_or_link` int(11) DEFAULT NULL,
  `file_link_type` int(11) DEFAULT NULL,
  `audio_link` text,
  `video_link` text,
  `file_type` int(11) DEFAULT NULL,
  `audio` text,
  `video` text,
  `feature_status` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `story_files`
--

INSERT INTO `story_files` (`id`, `category_id`, `title`, `description`, `file_or_link`, `file_link_type`, `audio_link`, `video_link`, `file_type`, `audio`, `video`, `feature_status`, `created_at`, `updated_at`) VALUES
(1, 1, 'fffffffffffff', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660901735_1650698389_sample-mp4-file-small.mp4', 1, '2022-08-19 03:35:35', '2022-09-10 14:47:48'),
(2, 2, 'gggggggg', NULL, 2, NULL, NULL, NULL, 2, NULL, '1660910912_1650698389_sample-mp4-file-small.mp4', 0, '2022-08-19 06:08:32', '2022-09-12 23:46:02'),
(3, 4, 'Story 01', NULL, 2, NULL, NULL, NULL, 1, '1662660772_10-01.mp3', NULL, NULL, '2022-09-08 23:12:52', '2022-09-08 23:12:52'),
(4, 4, 'ghgghh', NULL, 2, NULL, NULL, NULL, 2, NULL, '1663008500_1650698389_sample-mp4-file-small.mp4', NULL, '2022-09-12 23:48:20', '2022-09-12 23:48:20'),
(5, 1, 'dsfbgfshbfs', NULL, 2, NULL, NULL, NULL, 2, NULL, '1663008559_1650698389_sample-mp4-file-small.mp4', 0, '2022-09-12 23:49:19', '2022-09-12 23:49:31');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `inst_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `group` int(11) NOT NULL,
  `student_class_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `subcategory_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `category_id`, `type_id`, `subcategory_name`, `created_at`, `updated_at`) VALUES
(21, 18, 11, 'Sifrei Admur Hazaken', '2022-05-31 17:46:59', '2022-05-31 17:46:59'),
(22, 18, 11, 'Sifrei Admur Haemtzoi', '2022-05-31 17:46:59', '2022-05-31 17:46:59'),
(23, 18, 11, 'Sifrei Tzemach Tzedek', '2022-05-31 17:46:59', '2022-05-31 17:46:59'),
(24, 18, 11, 'Sifrei Rebbe Maharash', '2022-06-02 14:43:56', '2022-06-02 14:43:56'),
(25, 18, 11, 'Sifrei Frierdiker Rebbe', '2022-06-02 14:43:56', '2022-06-02 14:43:56'),
(26, 18, 11, 'Sifrei Rebbe', '2022-06-02 14:43:56', '2022-06-02 14:43:56'),
(27, 18, 12, 'Chumash', '2022-06-02 14:44:34', '2022-06-02 14:44:34'),
(28, 18, 12, 'Rambam', '2022-06-02 14:44:34', '2022-06-02 14:44:34'),
(29, 18, 12, 'Gemara', '2022-06-02 14:44:34', '2022-06-02 14:44:34'),
(30, 18, 12, 'Shulchan Aruch', '2022-06-02 14:44:34', '2022-06-02 14:44:34'),
(31, 18, 12, 'Dof yomi', '2022-08-31 19:46:13', '2022-08-31 19:46:13'),
(32, 18, 12, 'Chumash', '2022-09-08 17:23:22', '2022-09-08 17:23:22'),
(33, 18, 12, 'Rambam', '2022-09-08 17:23:22', '2022-09-08 17:23:22'),
(34, 18, 12, 'Chumash', '2022-09-08 18:07:15', '2022-09-08 18:07:15'),
(35, 18, 12, 'Rambam', '2022-09-08 18:07:15', '2022-09-08 18:07:15');

-- --------------------------------------------------------

--
-- Table structure for table `sub_contents`
--

CREATE TABLE `sub_contents` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `subcontent_name` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sub_contents`
--

INSERT INTO `sub_contents` (`id`, `category_id`, `type_id`, `subcategory_id`, `content_id`, `speaker_id`, `subcontent_name`, `created_at`, `updated_at`) VALUES
(8, 18, 11, 21, 22, 12, NULL, '2022-05-31 22:48:16', '2022-05-31 22:48:16'),
(9, 18, 11, 21, 23, 12, NULL, '2022-06-05 21:59:14', '2022-06-05 21:59:14'),
(10, 18, 11, 21, 23, 13, NULL, '2022-06-05 22:00:02', '2022-06-05 22:00:02'),
(11, 18, 11, 21, 24, 12, NULL, '2022-06-05 22:00:31', '2022-06-05 22:00:31'),
(12, 18, 11, 21, 24, 13, NULL, '2022-06-05 22:00:55', '2022-06-05 22:00:55'),
(13, 18, 11, 21, 22, 21, NULL, '2022-09-08 22:24:06', '2022-09-08 22:24:06'),
(14, 18, 11, 21, 22, 21, NULL, '2022-09-08 22:28:39', '2022-09-08 22:28:39');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` int(11) NOT NULL,
  `inst_id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `topics_categories`
--

CREATE TABLE `topics_categories` (
  `id` int(11) NOT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `category_name` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `topics_categories`
--

INSERT INTO `topics_categories` (`id`, `topic_id`, `category_name`, `created_at`, `updated_at`) VALUES
(5, 20, 'Parshiyos', '2022-06-16 21:34:32', '2022-06-16 21:34:32'),
(6, 20, 'Yomim Tovim', '2022-06-16 21:34:53', '2022-06-16 21:34:53'),
(7, 20, '13 Ikrim: Moshiach', '2022-06-16 21:35:14', '2022-06-16 21:35:14'),
(8, 20, '14 Ikrim: Schdus Hashem', '2022-06-16 21:35:33', '2022-06-16 21:35:33'),
(9, 20, '15 Ikrim: Reward and Punishment', '2022-06-16 21:35:48', '2022-06-16 21:35:48'),
(10, 20, '16 Ikrim: Techiyas Hameisim', '2022-06-16 21:36:00', '2022-06-16 21:36:00'),
(11, 20, '17 Ikrim: Moshiach', '2022-06-16 21:36:22', '2022-06-16 21:36:22'),
(12, 20, 'Inyonei geulah umoshiach', '2022-09-01 00:48:46', '2022-09-01 00:48:46');

-- --------------------------------------------------------

--
-- Table structure for table `topics_of_sichos_categories`
--

CREATE TABLE `topics_of_sichos_categories` (
  `id` int(11) NOT NULL,
  `sichos_category_name` varchar(255) DEFAULT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `topics_of_sichos_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `topics_of_sichos_categories`
--

INSERT INTO `topics_of_sichos_categories` (`id`, `sichos_category_name`, `main_cat_id`, `topics_of_sichos_id`, `created_at`, `updated_at`) VALUES
(1, '13 Ikrim: Moshiach', 7, 5, '2022-06-17 14:02:21', '2022-06-17 14:02:21');

-- --------------------------------------------------------

--
-- Table structure for table `upcoming_holidays`
--

CREATE TABLE `upcoming_holidays` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `main_cat_id` int(11) DEFAULT NULL,
  `holiday_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `upload_files`
--

CREATE TABLE `upload_files` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `subcontent_id` int(11) DEFAULT NULL,
  `lecture_id` int(11) DEFAULT NULL,
  `speaker_id` int(11) DEFAULT NULL,
  `short_description` text COLLATE utf8_unicode_ci,
  `title` text COLLATE utf8_unicode_ci,
  `topics` text COLLATE utf8_unicode_ci,
  `file_type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `audio_link` text COLLATE utf8_unicode_ci,
  `video_link` text COLLATE utf8_unicode_ci,
  `file_link_type` int(11) DEFAULT NULL,
  `audio` text COLLATE utf8_unicode_ci,
  `video` text COLLATE utf8_unicode_ci,
  `pdf` text COLLATE utf8_unicode_ci,
  `date` char(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `month` char(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `upload_files`
--

INSERT INTO `upload_files` (`id`, `category_id`, `type_id`, `subcategory_id`, `content_id`, `subcontent_id`, `lecture_id`, `speaker_id`, `short_description`, `title`, `topics`, `file_type`, `status`, `audio_link`, `video_link`, `file_link_type`, `audio`, `video`, `pdf`, `date`, `month`, `created_at`, `updated_at`) VALUES
(49, 18, 11, 21, 22, NULL, 21, 12, 'Test Audio Class 1', 'Test Audio Class 1', NULL, 1, NULL, NULL, NULL, NULL, '1654019455_10-10.mp3', NULL, NULL, '05', '09', '2022-05-31 22:50:55', '2022-09-05 21:30:04'),
(50, 18, 11, 21, 22, NULL, 21, 12, NULL, 'Test Audio Class 2', NULL, 1, NULL, NULL, NULL, NULL, '1654019623_10-09.mp3', NULL, NULL, '13', '09', '2022-05-31 22:53:43', '2022-09-13 23:08:52'),
(51, 18, 11, 21, 22, NULL, 21, 12, NULL, 'Test Video Class 1', NULL, 2, NULL, NULL, NULL, NULL, NULL, '1654019891_Untitled 14.mp4', NULL, '13', '09', '2022-05-31 22:58:11', '2022-09-13 23:09:06'),
(52, 18, 11, 21, 25, NULL, NULL, NULL, NULL, 'Class 1', NULL, 1, NULL, NULL, NULL, NULL, '1654202027_10-10.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:33:47', '2022-06-03 01:33:47'),
(53, 18, 11, 21, 26, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202065_10-09.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:34:25', '2022-06-03 01:34:25'),
(54, 18, 11, 21, 27, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202188_10-08.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:36:28', '2022-06-03 01:36:28'),
(55, 18, 11, 21, 28, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202215_10-07.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:36:55', '2022-06-03 01:36:55'),
(56, 18, 11, 22, 29, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202264_10-06.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:37:44', '2022-06-03 01:37:44'),
(57, 18, 11, 22, 30, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202333_10-05.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:38:53', '2022-06-03 01:38:53'),
(58, 18, 11, 23, 31, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202358_10-01 (1).mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:39:18', '2022-06-03 01:39:18'),
(59, 18, 11, 24, 32, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202392_10-10.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:39:52', '2022-06-03 01:39:52'),
(60, 18, 11, 24, 33, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202424_10-09.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:40:24', '2022-06-03 01:40:24'),
(61, 18, 11, 25, 34, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202454_10-08.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:40:54', '2022-06-03 01:40:54'),
(62, 18, 11, 25, 35, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202480_10-06.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:41:20', '2022-06-03 01:41:20'),
(63, 18, 11, 25, 36, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202512_10-05.mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:41:52', '2022-06-03 01:41:52'),
(64, 18, 12, 27, NULL, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202553_10-04.mp3', NULL, NULL, '13', '09', '2022-06-03 01:42:33', '2022-09-13 23:08:14'),
(65, 18, 12, 28, NULL, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202580_10-03 (1).mp3', NULL, NULL, '13', '09', '2022-06-03 01:43:00', '2022-09-13 23:12:16'),
(66, 18, 12, 29, NULL, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202600_10-02 (1).mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:43:20', '2022-06-03 01:43:20'),
(67, 18, 12, 30, NULL, NULL, NULL, NULL, NULL, 'Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1654202625_10-01 (1).mp3', NULL, NULL, NULL, NULL, '2022-06-03 01:43:45', '2022-06-03 01:43:45'),
(68, 18, 11, 21, 23, NULL, 28, 12, 'Short Description', 'Test File', 'topics, video file', 2, NULL, NULL, NULL, NULL, NULL, '1654448730_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, '2022-06-05 22:05:30', '2022-06-05 22:05:30'),
(69, 18, 11, 21, 23, NULL, 29, 12, 'Short Description', 'Content file', 'topics', 2, NULL, NULL, NULL, NULL, NULL, '1654448806_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, '2022-06-05 22:06:46', '2022-06-05 22:06:46'),
(70, 18, 11, 21, 24, NULL, 31, 13, 'Short Description', 'Content file', 'Topics', 2, NULL, NULL, NULL, NULL, NULL, '1654448867_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, '2022-06-05 22:07:47', '2022-06-05 22:07:47'),
(71, 18, 11, 21, 24, NULL, 33, 13, 'Short Description', 'File Title', 'Topics', 2, NULL, NULL, NULL, NULL, NULL, '1654449034_1650698389_sample-mp4-file-small.mp4', NULL, NULL, NULL, '2022-06-05 22:10:34', '2022-06-05 22:10:34'),
(72, 18, 11, 24, 37, NULL, NULL, 13, NULL, 'Hayom yom file title', 'tghjtrs', 2, NULL, NULL, NULL, NULL, NULL, '1662395606_1650698389_sample-mp4-file-small.mp4', NULL, '13', '09', '2022-09-05 21:33:26', '2022-09-13 23:09:37'),
(73, 18, 12, 31, NULL, NULL, NULL, NULL, NULL, 'Dof Yomi file title', NULL, 2, NULL, NULL, NULL, NULL, NULL, '1662396089_1650698389_sample-mp4-file-small.mp4', NULL, '13', '09', '2022-09-05 21:41:29', '2022-09-13 23:10:30'),
(74, 18, 11, 21, 22, NULL, 21, 12, NULL, 'Lesson 50', NULL, 1, NULL, NULL, NULL, NULL, '1662656957_10-06.mp3', NULL, NULL, '14', '09', '2022-09-08 22:09:17', '2022-09-13 23:09:22'),
(75, 18, 11, 21, 22, NULL, 21, 12, 'demo', 'Lesson sample 01', 'Tanya', 1, NULL, NULL, NULL, NULL, '1662657998_10-07.mp3', NULL, NULL, NULL, NULL, '2022-09-08 22:26:38', '2022-09-08 22:26:38'),
(76, 18, 11, 21, 22, NULL, 21, 12, 'Demo', 'Demo Class 01', NULL, 1, NULL, NULL, NULL, NULL, '1662660522_10-05.mp3', NULL, NULL, NULL, NULL, '2022-09-08 23:08:42', '2022-09-08 23:08:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `email_verified_at`, `username`, `type`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'shoriful islam', 'shorifuluap@gmail.com', 1723861278, NULL, 'admin@gmail.com', NULL, '$2y$10$2d2nU1hkI8/P3LRXPb2zP.Qt5IR2CfXKzCEuH2.fTrsf7Q6sc9MVC', NULL, '2022-04-22 16:48:44', '2022-04-22 16:48:44'),
(2, 'shoriful islam', 'ggg@gmail.com', 5653634, NULL, 'ggg@gmail.com', NULL, '$2y$10$J8iR1KOu10.SnPPwHgJNu.KhRIL9zv1V3QcWtmWCHhnC.w7xzBAJ2', NULL, '2022-04-22 23:58:18', '2022-04-22 23:58:18'),
(3, 'shoriful islam', 'digigate@gmail.com', 84658437, NULL, 'digigate@gmail.com', NULL, '$2y$10$GZs5fu9LcC4kDdM5kwYHSOILzG8kCI51uyJPgP/Qnh6ui7j9/8yzG', NULL, '2022-04-23 04:29:53', '2022-04-23 04:29:53'),
(4, 'Shoriful', 'shorif@gmail.com', 1723861154, NULL, 'shorif@gmail.com', 'user', '$2y$10$.Q8eNod8PmVqHRetA6t1GOQm9jxvLFkb0p7BnGhdUDi2q45jyxQdW', NULL, '2022-05-13 22:10:42', '2022-05-13 22:10:42'),
(5, 'Shoriful', 'ys@gmail.com', 1723861153, NULL, 'ys@gmail.com', 'user', '$2y$10$XOOt/m9iOAK67F1GurQjkeP1mt2nhkzQCDU6ysnR73PPeOeFmX7qy', NULL, '2022-05-15 20:43:35', '2022-05-15 20:43:35'),
(6, 'Shoriful', 'ys1@gmail.com', 1723861152, NULL, 'ys1@gmail.com', 'customer', '$2y$10$l/FtpIbfsejs1QyEHJfl2.Q3chW4CuSlFEwvqsZidGqJ1aP34JBY2', NULL, '2022-05-15 20:45:01', '2022-05-15 20:45:01'),
(7, 'Demo', 'demo@gmail.com', 123543243, NULL, 'demo@gmail.com', 'customer', '$2y$10$qiY3xTu4rdB4RYbJ.IQS6egyLwyZO7yGl6h.7ZTLQkxS2mgOR6.LO', NULL, '2022-05-26 00:14:18', '2022-05-26 00:14:18'),
(8, 'yeydhd', 'chchchx', 855555, NULL, 'chchchx', 'customer', '$2y$10$LOyVixLdGH3P87h1g/.JtO0UXPavIL3hEANejQIabA4ZH2hfmAhMy', NULL, '2022-06-27 11:43:49', '2022-06-27 11:43:49'),
(9, 'ray', 'b@gmail.com', 1932838565, NULL, 'b@gmail.com', 'customer', '$2y$10$L9vzvipKI.aduC7IbB5aROit9c07y/AZQZ5ML0jKhDJrCCNWofRJm', NULL, '2022-06-27 12:20:21', '2022-06-27 12:20:21'),
(10, 'some name', 'test@gmail.com', 1234567891, NULL, 'test@gmail.com', 'customer', '$2y$10$/7p1gqalnuuoYYh1ew0AQOhypdWrkbdcNCgjjevR/tey4ALALtpFa', NULL, '2022-06-28 01:01:11', '2022-06-28 01:01:11'),
(11, 'some', 'test2@gmail.com', 1234567892, NULL, 'test2@gmail.com', 'customer', '$2y$10$ReLvTBKmdPbai9SUt3y.C.tzkc6LcIElsPE0o/O0hilbEByPmSMWK', NULL, '2022-06-28 01:08:10', '2022-06-28 01:08:10'),
(12, 'Joel', 'joel21@gmail.com', 75157854, NULL, 'joel21@gmail.com', 'customer', '$2y$10$2VLgqibOPLwg.7xfLTSZcuP3bzK5wpB2nIs3L.2uhjn9JkEdLnAj.', NULL, '2022-07-19 07:38:47', '2022-07-19 07:38:47');

-- --------------------------------------------------------

--
-- Table structure for table `years`
--

CREATE TABLE `years` (
  `id` int(11) NOT NULL,
  `year` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `years`
--

INSERT INTO `years` (`id`, `year`, `created_at`, `updated_at`) VALUES
(3, '5710', '2022-08-13 14:38:01', '2022-08-13 14:38:01'),
(4, '5711', '2022-08-15 16:25:24', '2022-08-15 16:25:24'),
(5, '5712', '2022-08-15 16:25:30', '2022-08-15 16:25:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `albams_lists`
--
ALTER TABLE `albams_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_types`
--
ALTER TABLE `category_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `current_parsha_lists`
--
ALTER TABLE `current_parsha_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farbrengen_dates`
--
ALTER TABLE `farbrengen_dates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farbrengen_files`
--
ALTER TABLE `farbrengen_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farbrengen_months`
--
ALTER TABLE `farbrengen_months`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feature_files`
--
ALTER TABLE `feature_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `following_speakers`
--
ALTER TABLE `following_speakers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `holiday_lists`
--
ALTER TABLE `holiday_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kol_rabeinu_categories`
--
ALTER TABLE `kol_rabeinu_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kol_rabeinu_files`
--
ALTER TABLE `kol_rabeinu_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kol_rabeinu_sub_categories`
--
ALTER TABLE `kol_rabeinu_sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lectures`
--
ALTER TABLE `lectures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listen_later_files`
--
ALTER TABLE `listen_later_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main_story_categories`
--
ALTER TABLE `main_story_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `months`
--
ALTER TABLE `months`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `muggidei_lists`
--
ALTER TABLE `muggidei_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `niggun_categories`
--
ALTER TABLE `niggun_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nigunim_categories`
--
ALTER TABLE `nigunim_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nigunim_files`
--
ALTER TABLE `nigunim_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parshioys_contents`
--
ALTER TABLE `parshioys_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parshiyos_files`
--
ALTER TABLE `parshiyos_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parshiyos_groups`
--
ALTER TABLE `parshiyos_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parshiyos_types`
--
ALTER TABLE `parshiyos_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(191));

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`(191),`tokenable_id`);

--
-- Indexes for table `recently_played_lists`
--
ALTER TABLE `recently_played_lists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `speakers`
--
ALTER TABLE `speakers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `std_classes`
--
ALTER TABLE `std_classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `story_categories`
--
ALTER TABLE `story_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `story_files`
--
ALTER TABLE `story_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_contents`
--
ALTER TABLE `sub_contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topics_categories`
--
ALTER TABLE `topics_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topics_of_sichos_categories`
--
ALTER TABLE `topics_of_sichos_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upcoming_holidays`
--
ALTER TABLE `upcoming_holidays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upload_files`
--
ALTER TABLE `upload_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `years`
--
ALTER TABLE `years`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `albams_lists`
--
ALTER TABLE `albams_lists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `category_types`
--
ALTER TABLE `category_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `current_parsha_lists`
--
ALTER TABLE `current_parsha_lists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `farbrengen_dates`
--
ALTER TABLE `farbrengen_dates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `farbrengen_files`
--
ALTER TABLE `farbrengen_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `farbrengen_months`
--
ALTER TABLE `farbrengen_months`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feature_files`
--
ALTER TABLE `feature_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `following_speakers`
--
ALTER TABLE `following_speakers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `holiday_lists`
--
ALTER TABLE `holiday_lists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `kol_rabeinu_categories`
--
ALTER TABLE `kol_rabeinu_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `kol_rabeinu_files`
--
ALTER TABLE `kol_rabeinu_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `kol_rabeinu_sub_categories`
--
ALTER TABLE `kol_rabeinu_sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `lectures`
--
ALTER TABLE `lectures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `listen_later_files`
--
ALTER TABLE `listen_later_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `main_story_categories`
--
ALTER TABLE `main_story_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `months`
--
ALTER TABLE `months`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `muggidei_lists`
--
ALTER TABLE `muggidei_lists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `niggun_categories`
--
ALTER TABLE `niggun_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `nigunim_categories`
--
ALTER TABLE `nigunim_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `nigunim_files`
--
ALTER TABLE `nigunim_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `parshioys_contents`
--
ALTER TABLE `parshioys_contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `parshiyos_files`
--
ALTER TABLE `parshiyos_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `parshiyos_groups`
--
ALTER TABLE `parshiyos_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `parshiyos_types`
--
ALTER TABLE `parshiyos_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recently_played_lists`
--
ALTER TABLE `recently_played_lists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=345;

--
-- AUTO_INCREMENT for table `speakers`
--
ALTER TABLE `speakers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `story_categories`
--
ALTER TABLE `story_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `story_files`
--
ALTER TABLE `story_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `sub_contents`
--
ALTER TABLE `sub_contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `topics_categories`
--
ALTER TABLE `topics_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `topics_of_sichos_categories`
--
ALTER TABLE `topics_of_sichos_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `upcoming_holidays`
--
ALTER TABLE `upcoming_holidays`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `upload_files`
--
ALTER TABLE `upload_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `years`
--
ALTER TABLE `years`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
